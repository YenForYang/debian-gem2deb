module Gem2Deb
  VERSION = '0.40'
end
